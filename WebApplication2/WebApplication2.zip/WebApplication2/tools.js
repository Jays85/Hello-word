﻿//兼容IE和非IE删除外联CSS文件中的样式
function tDeleteRule(sheetstyle,position) {
    if (typeof sheetstyle.deleteRule != 'undefined') {
        sheetstyle.deleteRule(position);
    }
    else {
        sheetstyle.removeRule(position);
    }
}
//兼容IE和非IE添加外联CSS文件中的样式
function tAddRule(sheetstyle,cssrule,csstext,position) {
    if (typeof sheetstyle.insertRule != 'undefined') {
        var cssstr = cssrule + '{' + csstext + '}';
        sheetstyle.insertRule(cssstr, position);
    }
    else {
        sheetstyle.addRule(cssrule, csstext, position);
    }
}
//兼容IE非IE获取行内，外连CSS属性值
function tCss(element,attr) {
    if (typeof window.getComputedStyle != 'undefined') {//判断非IE方法是否合法，如果合法就调用
        return window.getComputedStyle(element, null)[attr];
    }
    else if (typeof element.currentStyle != 'undefined') {//判断IE方法是否合法，如果合法调用
        return element.currentStyle[attr];
    }
    else {
        return element.style[attr]; //读取行内style
    }
}
//兼容IE非IE获取视窗大小
function tGetInner() {
    debugger;
    if (typeof window.innerWidth != 'undefined') {
        return {
            width: window.innerWidth, 
            height: window.innerHeight
        }
    }
    else{
        return {
            width: document.documentElement.clientWidth,
            height: document.documentElement.clientHeight
        }
    }
}
function tGetEvent(event) {
    return event || window.event;
}