﻿//前台用$()来实例化一个新对像
var $ = function (_this) {
    return new Base(_this);
 }
function Base(_this) {
    this.Ems = [];
    if (_this != undefined) {
        this.Ems[0] = _this;
    }
    //跟据ID获取元素
    this.getId = function (id) {
        this.Ems.push(document.getElementById(id));
        return this;
    };
    //跟据标签名获取元素
    this.getTagName = function (TagName) {
        var TagNames = document.getElementsByTagName(TagName);
        for (var i = 0; i < TagNames.length; i++) {
            this.Ems.push(TagNames[i]);
        }
        return this;
    }
    //跟据class类名获取元数
    this.getClassName = function (ClassName, Id) {
        var TagNames
        if (arguments.length == 1) {//只有一个属性就所有ClassName元素
            TagNames = document.getElementsByTagName('*');
        }
        else {//否则跟据ID获取ID区块下所有ClassName元素
            TagNames = document.getElementById(Id).getElementsByTagName('*');
        }
        for (var i = 0; i < TagNames.length; i++) {
            if (TagNames[i].className == ClassName) {
                this.Ems.push(TagNames[i]);
            }
        }
        return this;
    }
    //删除属性
    this.delClass = function (ClassName) {
        for (var i = 0; i < this.Ems.length; i++) {
            this.Ems[i].removeAttribute(ClassName);
        }
        return this;
    }
    //添加删除Class属性
    this.addClass = function (ClassName, ClassValue) {
        for (var i = 0; i < this.Ems.length; i++) {
            if (arguments.length == 1) {
                this.Ems[i].removeAttribute(ClassName);
            }
            else {
                this.Ems[i].setAttribute(ClassName, ClassValue);
            }
        }
        return this;
    }
    //获取元素集合中指定元素
    this.getElement = function (num) {
        if (arguments.length == 1) {
            var element = this.Ems[num];
            this.Ems = [];
            this.Ems[0] = element;
            return this;
        }
        else {
            return this;
        }
    }
};
//鼠标移动事件
Base.prototype.Hover = function (over, out) {
    for (var i = 0; i < this.Ems.length; i++) {
        this.Ems[i].onmouseover = over;
        this.Ems[i].onmouseout = out;
    }
    return this;
}
//显示指定区块
Base.prototype.show = function () {
    for (var i = 0; i < this.Ems.length; i++) {
        this.Ems[i].style.display = 'block';
    }
    return this;
}

//设置隐藏区块
Base.prototype.hide = function () {
    for (var i = 0; i < this.Ems.length; i++) {
        this.Ems[i].style.display = 'none';
    }
    return this;
}

//添加删除外联CSS规则
Base.prototype.addRule = function (num, cssrule, csstext, position) {
    var sheetstyle = document.styleSheets[num];
    if (arguments.length == 2) {
        tDeleteRule(sheetstyle, position);
    }
    else if (arguments.length == 4) {
        tAddRule(sheetstyle,cssrule,csstext,position);
    }
    return this;
}  //设置元素居中
Base.prototype.setCenter = function (width, height) {
    var top = (document.documentElement.clientHeight - height) / 2;
    var left = (document.documentElement.clientWidth - width) / 2;
        for (var i = 0; i < this.Ems.length; i++) {
            this.Ems[i].style.top = top + 'px';
            this.Ems[i].style.left = left + 'px';
    }
    return this;
}
//窗体改变事件
Base.prototype.reSize = function (fn) {
    window.onresize = fn;
    return this;
}
//设置行内CSS样式
Base.prototype.Css = function (attr, value) {
    for (var i = 0; i < this.Ems.length; i++) {
        if (arguments.length == 1) {//判断只有一个属性那么就取读CSS属性值
           return tCss(this.Ems[i], attr);
        }
        else {
            this.Ems[i].style[attr] = value;
        }
    }
    return this;
}
//添加单击方法
Base.prototype.Click = function (fn) {
    for (var i = 0; i < this.Ems.length; i++) {
        this.Ems[i].onclick = fn;
    }
    return this;
}
//设置元素文本内容
Base.prototype.Html = function (str) {
    for (var i = 0; i < this.Ems.length; i++) {
        if (arguments.length == 0) {
            return this.Ems[i].innerHTML;
        }
        this.Ems[i].innerHTML = str;
    }
    return this;
}
//设置锁屏
Base.prototype.operationLock = function (status) {
    for (var i = 0; i < this.Ems.length; i++) {
        if (status == 'lock') {
            this.Ems[i].style.width = tGetInner().width + 'px';
            this.Ems[i].style.height = tGetInner().height + 'px';
            this.Ems[i].style.display = 'block';
            document.documentElement.style.overflow = 'hidden';
        }
        else if (status == 'unlock') {
            this.Ems[i].style.display = 'none';
            document.documentElement.style.overflow = 'auto';
        }
    }
    return this;
}

Base.prototype.onMouseMove = function (str) {
    var screen = $().getId('screen');
    for (var i = 0; i < this.Ems.length; i++) {
        this.Ems[i].onmousedown = function (e) {
            var e = tGetEvent(e);
            var _this = this;
            var elementX = e.clientX - _this.offsetLeft;
            var elementY = e.clientY - _this.offsetTop;
            document.onmousemove = function (e) {
                var e = tGetEvent(e);
                screen.operationLock('lock');
                _this.style.left = e.clientX - elementX + 'px';
                _this.style.top = e.clientY - elementY + 'px';
            }
            document.onmouseup = function () {
                document.onmousemove = null;
                document.onmouseup = null;
            }
        }
        return this;
    }

}







